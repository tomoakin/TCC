### R code from vignette source 'TCC.Rnw'

###################################################
### code chunk number 1: TCC.Rnw:149-150
###################################################
citation("TCC")


###################################################
### code chunk number 2: TCC.Rnw:180-190
###################################################
library(TCC)
data(hypoData)
samplesize <- 100
group <- c(1, 1, 1, 2, 2, 2)
tcc <- new("TCC", hypoData, group)
tcc <- calcNormFactors(tcc, norm.method = "tmm", test.method = "bayseq",
                       iteration = 1, samplesize = samplesize) 
tcc <- estimateDE(tcc, test.method = "edger", FDR = 0.1)
result <- getResult(tcc, sort = TRUE)
head(result)


###################################################
### code chunk number 3: TCC.Rnw:205-214
###################################################
library(TCC)
data(hypoData)
group <- c(1, 1, 1, 2, 2, 2)
tcc <- new("TCC", hypoData, group)
tcc <- calcNormFactors(tcc, norm.method = "tmm", test.method = "edger", 
                       iteration = 3, FDR = 0.1, floorPDEG = 0.05)
tcc <- estimateDE(tcc, test.method = "edger", FDR = 0.1)
result <- getResult(tcc, sort = TRUE)
head(result)


###################################################
### code chunk number 4: TCC.Rnw:227-236
###################################################
library(TCC)
data(hypoData)
group <- c(1, 2)
tcc <- new("TCC", hypoData[,c(1,4)], group)
tcc <- calcNormFactors(tcc, norm.method = "deseq", test.method = "deseq",
                       iteration = 3, FDR = 0.1, floorPDEG = 0.05)
tcc <- estimateDE(tcc, test.method = "deseq", FDR = 0.1)
result <- getResult(tcc, sort = TRUE)
head(result)


###################################################
### code chunk number 5: TCC.Rnw:259-264
###################################################
library(TCC)
data(hypoData)
head(hypoData)
dim(hypoData)
group <- c(1, 1, 1, 2, 2, 2)


###################################################
### code chunk number 6: TCC.Rnw:272-273
###################################################
group <- c(1, 1, 1, 1, 2, 2, 2, 2, 2)


###################################################
### code chunk number 7: TCC.Rnw:286-291
###################################################
library(TCC)
data(hypoData)
group <- c(1, 1, 1, 2, 2, 2)
tcc <- new("TCC", hypoData, group)
tcc


###################################################
### code chunk number 8: TCC.Rnw:298-300
###################################################
head(tcc$count)
tcc$group


###################################################
### code chunk number 9: TCC.Rnw:307-312
###################################################
dim(tcc$count)
tcc.sub1 <- subset(tcc, c(rep(TRUE, 20), rep(FALSE, 980)))
dim(tcc.sub1$count)
tcc.sub2 <- tcc[1:20]
dim(tcc.sub2$count)


###################################################
### code chunk number 10: TCC.Rnw:324-330
###################################################
library(TCC)
data(hypoData)
group <- c(1, 1, 1, 2, 2, 2)
tcc <- new("TCC", hypoData, group)
tcc <- filterLowCountGenes(tcc)
dim(tcc$count)


###################################################
### code chunk number 11: TCC.Rnw:340-344
###################################################
filter <- as.logical(rowSums(hypoData) > 0)
dim(hypoData[filter, ])
tcc <- new("TCC", hypoData[filter, ], group)
dim(tcc$count)


###################################################
### code chunk number 12: TCC.Rnw:382-390
###################################################
set.seed(1000)
library(TCC)
data(hypoData)
samplesize <- 70
group <- c(1, 1, 1, 2, 2, 2)
tcc <- new("TCC", hypoData, group)
tcc <- calcNormFactors(tcc, norm.method = "tmm", test.method = "bayseq",
                       iteration = 1, samplesize = samplesize)


###################################################
### code chunk number 13: TCC.Rnw:409-411
###################################################
tcc$norm.factors
tcc$DEGES$execution.time


###################################################
### code chunk number 14: TCC.Rnw:420-445
###################################################
set.seed(1000)
library(TCC)
data(hypoData)
samplesize <- 70
group <- c(1, 1, 1, 2, 2, 2)
### STEP 1 ###
d <- DGEList(count = hypoData, group = group)
d <- calcNormFactors(d)
norm.factors <- d$samples$norm.factors
norm.factors <- norm.factors / mean(norm.factors)
### STEP 2 ###
cD <- new("countData", data = hypoData, replicates = group,
         groups = list(NDE = rep(1, length = length(group)), DE = group),
         libsizes = colSums(hypoData) * norm.factors)
cD <- getPriors.NB(cD, samplesize = samplesize, estimation = "QL", cl = NULL)
cD <- getLikelihoods.NB(cD, pET = "BIC", cl = NULL)
is.DEG <- as.logical(rank(-cD@posteriors[, "DE"]) < 
                     (nrow(hypoData) * cD@estProps[2]))
### STEP 3 ###
d <- DGEList(count = hypoData[!is.DEG, ], group = group)
d <- calcNormFactors(d)
norm.factors <- d$samples$norm.factors * colSums(hypoData[!is.DEG, ]) / 
                colSums(hypoData)
norm.factors <- norm.factors / mean(norm.factors)
norm.factors


###################################################
### code chunk number 15: TCC.Rnw:466-474
###################################################
library(TCC)
data(hypoData)
group <- c(1, 1, 1, 2, 2, 2)
tcc <- new("TCC", hypoData, group)
tcc <- calcNormFactors(tcc, norm.method = "tmm", test.method = "edger", 
                       iteration = 1, FDR = 0.1, floorPDEG = 0.05)
tcc$norm.factors
tcc$DEGES$execution.time


###################################################
### code chunk number 16: TCC.Rnw:485-511
###################################################
library(TCC)
data(hypoData)
group <- c(1, 1, 1, 2, 2, 2)
FDR <- 0.1
floorPDEG <- 0.05
d <- DGEList(counts = hypoData, group = group)
### STEP 1 ###
d <- calcNormFactors(d)
### STEP 2 ###
d <- estimateCommonDisp(d)
d <- estimateTagwiseDisp(d)
result <- exactTest(d)
q.value <- p.adjust(result$table$PValue, method = "BH")
if (sum(q.value < FDR) > (floorPDEG * nrow(hypoData))) {
  is.DEG <- as.logical(q.value < FDR)
} else {
  is.DEG <- as.logical(rank(result$table$PValue, ties.method = "min") <=
                       nrow(hypoData) * floorPDEG)
}
### STEP 3 ###
d <- DGEList(counts = hypoData[!is.DEG, ], group = group)
d <- calcNormFactors(d)
norm.factors <- d$samples$norm.factors * colSums(hypoData[!is.DEG, ]) /
                  colSums(hypoData)
norm.factors <- norm.factors / mean(norm.factors)
norm.factors


###################################################
### code chunk number 17: TCC.Rnw:529-537
###################################################
library(TCC)
data(hypoData)
group <- c(1, 1, 1, 2, 2, 2)
tcc <- new("TCC", hypoData, group)
tcc <- calcNormFactors(tcc, norm.method = "tmm", test.method = "edger", 
                       iteration = 3, FDR = 0.1, floorPDEG = 0.05)
tcc$norm.factors
tcc$DEGES$execution.time


###################################################
### code chunk number 18: TCC.Rnw:549-557
###################################################
library(TCC)
data(hypoData)
group <- c(1, 1, 1, 2, 2, 2)
tcc <- new("TCC", hypoData, group)
tcc <- calcNormFactors(tcc, norm.method = "deseq", test.method = "deseq",
                       iteration = 1, FDR = 0.1, floorPDEG = 0.05)
tcc$norm.factors
tcc$DEGES$execution.time


###################################################
### code chunk number 19: TCC.Rnw:566-592
###################################################
library(TCC)
data(hypoData)  
group <- c(1, 1, 1, 2, 2, 2)
FDR <- 0.1
floorPDEG <- 0.05
cds <- newCountDataSet(hypoData, group)
### STEP 1 ###
cds <- estimateSizeFactors(cds)
### STEP 2 ###
cds <- estimateDispersions(cds)
result <- nbinomTest(cds, 1, 2)
result$pval[is.na(result$pval)] <- 1
result$padj[is.na(result$padj)] <- 1
q.value <- result$padj
if (sum(q.value < FDR) > (floorPDEG * nrow(hypoData))) {
  is.DEG <- as.logical(q.value < FDR)
} else {
  is.DEG <- as.logical(rank(result$pval, ties.method = "min") <=
                       nrow(hypoData) * floorPDEG)
}
### STEP 3 ###
cds <- newCountDataSet(hypoData[!is.DEG, ], group)
cds <- estimateSizeFactors(cds)
norm.factors <- sizeFactors(cds) / colSums(hypoData)
norm.factors <- norm.factors / mean(norm.factors)
norm.factors


###################################################
### code chunk number 20: TCC.Rnw:621-627
###################################################
library(TCC)
data(hypoData)
group <- c(1, 2)
tcc <- new("TCC", hypoData[, c(1, 4)], group)
head(tcc$count)
tcc$group


###################################################
### code chunk number 21: TCC.Rnw:633-636
###################################################
tcc <- calcNormFactors(tcc, norm.method = "deseq", test.method = "deseq",
                       iteration = 1, FDR = 0.1, floorPDEG = 0.05)
tcc$norm.factors


###################################################
### code chunk number 22: TCC.Rnw:644-670
###################################################
library(TCC)
data(hypoData)
group <- c(1, 2)
FDR <- 0.1
floorPDEG <- 0.05
cds <- newCountDataSet(hypoData[, c(1, 4)], group)
### STEP 1 ###
cds <- estimateSizeFactors(cds)
### STEP 2 ###
cds <- estimateDispersions(cds, method = "blind", sharingMode = "fit-only")
result <- nbinomTest(cds, 1, 2)
result$pval[is.na(result$pval)] <- 1
result$padj[is.na(result$padj)] <- 1
q.value <- result$padj
if (sum(q.value < FDR) > (floorPDEG * nrow(hypoData))) {
  is.DEG <- as.logical(q.value < FDR)
} else {
  is.DEG <- as.logical(rank(result$pval, ties.method = "min") <=
                       nrow(hypoData) * floorPDEG)
}
### STEP 3 ###
cds <- newCountDataSet(hypoData[!is.DEG, c(1, 4)], group)
cds <- estimateSizeFactors(cds)
norm.factors <- sizeFactors(cds) / colSums(hypoData[, c(1, 4)])
norm.factors <- norm.factors / mean(norm.factors)
norm.factors


###################################################
### code chunk number 23: TCC.Rnw:685-691
###################################################
library(TCC)
data(hypoData_mg)
group <- c(1, 1, 1, 2, 2, 2, 3, 3, 3)
tcc <- new("TCC", hypoData_mg, group)
tcc
dim(tcc$count)


###################################################
### code chunk number 24: TCC.Rnw:710-719
###################################################
set.seed(1000)
library(TCC)
data(hypoData_mg)
samplesize <- 100
group <- c(1, 1, 1, 2, 2, 2, 3, 3, 3)
tcc <- new("TCC", hypoData_mg, group)
tcc <- calcNormFactors(tcc, norm.method = "tmm", test.method = "bayseq",
                       iteration = 1, samplesize = samplesize)
tcc$norm.factors


###################################################
### code chunk number 25: TCC.Rnw:732-738
###################################################
library(TCC)
data(hypoData_mg)
group <- c(1, 1, 1, 2, 2, 2, 3, 3, 3)
tcc <- new("TCC", hypoData_mg, group)
design <- model.matrix(~ as.factor(group))
coef <- 2:length(unique(group))


###################################################
### code chunk number 26: TCC.Rnw:746-749
###################################################
tcc <- calcNormFactors(tcc, norm.method = "tmm", test.method = "edger",
                        iteration = 1, design = design, coef = coef)
tcc$norm.factors


###################################################
### code chunk number 27: TCC.Rnw:758-790
###################################################
library(TCC)
data(hypoData_mg)
group <- c(1, 1, 1, 2, 2, 2, 3, 3, 3)
tcc <- new("TCC", hypoData_mg, group)
FDR <- 0.1
floorPDEG <- 0.05
design <- model.matrix(~ as.factor(group))
coef <- 2:length(unique(group))
d <- DGEList(counts = hypoData_mg, group = group)
### STEP 1 ###
d <- calcNormFactors(d)
### STEP 2 ###
d <- estimateGLMCommonDisp(d, design)
d <- estimateGLMTrendedDisp(d, design)
d <- estimateGLMTagwiseDisp(d, design)
fit <- glmFit(d, design)
lrt <- glmLRT(fit, coef = coef)
result <- topTags(lrt, n = nrow(hypoData_mg))
result <- result$table[rownames(hypoData_mg), ]
if (sum(result$FDR < FDR) > (floorPDEG * nrow(hypoData_mg))) {
  is.DEG <- as.logical(result$FDR < FDR)
} else  {
  is.DEG <- as.logical(rank(result$PValue, ties.method = "min") <=
                       nrow(hypoData_mg) * floorPDEG)
}
### STEP 3 ###
d <- DGEList(counts = hypoData_mg[!is.DEG, ], group = group)
d <- calcNormFactors(d)
norm.factors <- d$samples$norm.factors * colSums(hypoData_mg[!is.DEG, ]) /
                colSums(hypoData_mg)
norm.factors <- norm.factors / mean(norm.factors)
norm.factors


###################################################
### code chunk number 28: TCC.Rnw:802-808
###################################################
library(TCC)
data(hypoData_mg)
group <- c(1, 1, 1, 2, 2, 2, 3, 3, 3)
tcc <- new("TCC", hypoData_mg, group)
fit1 <- count ~ condition
fit0 <- count ~ 1


###################################################
### code chunk number 29: TCC.Rnw:814-817
###################################################
tcc <- calcNormFactors(tcc, norm.method = "deseq", test.method = "deseq",
                        iteration = 1, fit0 = fit0, fit1 = fit1)
tcc$norm.factors


###################################################
### code chunk number 30: TCC.Rnw:826-856
###################################################
library(TCC)
data(hypoData_mg)
group <- c(1, 1, 1, 2, 2, 2, 3, 3, 3)
FDR <- 0.1
floorPDEG <- 0.05
tcc <- new("TCC", hypoData_mg, group)
fit1 <- count ~ condition
fit0 <- count ~ 1
cds <- newCountDataSet(hypoData_mg, group)
### STEP 1 ###
cds <- estimateSizeFactors(cds)
### STEP 2 ###
cds <- estimateDispersions(cds)
reduced.model <- fitNbinomGLMs(cds, fit0)
full.model <- fitNbinomGLMs(cds, fit1)
p.value <- nbinomGLMTest(full.model, reduced.model)
p.value[is.na(p.value)] <- 1
q.value <- p.adjust(p.value, method = "BH")
if (sum(q.value < FDR) > (floorPDEG * nrow(hypoData_mg))) {
  is.DEG <- as.logical(q.value < FDR)
} else {
  is.DEG <- as.logical(rank(p.value, ties.method = "min") <=
                       nrow(hypoData_mg) * floorPDEG)
}
### STEP 3 ###
cds <- newCountDataSet(hypoData_mg[!is.DEG, ], group)
cds <- estimateSizeFactors(cds)
norm.factors <- sizeFactors(cds) / colSums(hypoData_mg)
norm.factors <- norm.factors / mean(norm.factors)
norm.factors


###################################################
### code chunk number 31: TCC.Rnw:898-902
###################################################
library(TCC)
data(hypoData)
nonDEG <- 201:1000
summary(hypoData[nonDEG, ])


###################################################
### code chunk number 32: TCC.Rnw:907-908
###################################################
apply(hypoData[nonDEG, ], 2, median)


###################################################
### code chunk number 33: TCC.Rnw:910-911
###################################################
hypoData.median <- apply(hypoData[nonDEG, ], 2, median)


###################################################
### code chunk number 34: TCC.Rnw:917-918
###################################################
normalized.count <- getNormalizedData(tcc)


###################################################
### code chunk number 35: TCC.Rnw:927-936
###################################################
library(TCC)
data(hypoData)  
nonDEG <- 201:1000
group <- c(1, 1, 1, 2, 2, 2)
tcc <- new("TCC", hypoData, group)
tcc <- calcNormFactors(tcc, norm.method = "tmm", test.method = "edger", 
                       iteration = 1, FDR = 0.1, floorPDEG = 0.05)
normalized.count <- getNormalizedData(tcc)
apply(normalized.count[nonDEG, ], 2, median)


###################################################
### code chunk number 36: TCC.Rnw:941-971
###################################################
library(TCC)
data(hypoData)
nonDEG <- 201:1000
group <- c(1, 1, 1, 2, 2, 2)
FDR <- 0.1
floorPDEG <- 0.05
d <- DGEList(counts = hypoData, group = group)
###  Step 1  ###
d <- calcNormFactors(d)
###  Step 2  ###
d <- estimateCommonDisp(d)
d <- estimateTagwiseDisp(d)
result <- exactTest(d)
q.value <- p.adjust(result$table$PValue, method = "BH")
if (sum(q.value < FDR) > (floorPDEG * nrow(hypoData))) {
  is.DEG <- as.logical(q.value < FDR)
} else {
  is.DEG <- as.logical(order(rank(result$table$PValue)) <= 
                       nrow(hypoData) * floorPDEG)
}
###  Step 3  ###
d <- DGEList(counts = hypoData[!is.DEG, ], group = group)
d <- calcNormFactors(d)
norm.factors <- d$samples$norm.factors * colSums(hypoData[!is.DEG, ]) /
                  colSums(hypoData)
norm.factors <- norm.factors / mean(norm.factors)
effective.libsizes <- colSums(hypoData) * norm.factors
normalized.count <- sweep(hypoData, 2,
                          mean(effective.libsizes) / effective.libsizes, "*")
apply(normalized.count[nonDEG, ], 2, median)


###################################################
### code chunk number 37: TCC.Rnw:983-995
###################################################
library(TCC)
data(hypoData)
nonDEG <- 201:1000
group <- c(1, 1, 1, 2, 2, 2)
d <- DGEList(count = hypoData, group = group)
d <- calcNormFactors(d)
norm.factors <- d$samples$norm.factors
norm.factors <- norm.factors / mean(norm.factors)
effective.libsizes <- colSums(hypoData) * norm.factors
normalized.count <- sweep(hypoData, 2, 
                          mean(effective.libsizes) / effective.libsizes, "*")
apply(normalized.count[nonDEG, ], 2, median)


###################################################
### code chunk number 38: TCC.Rnw:1000-1008
###################################################
library(TCC)
data(hypoData)
nonDEG <- 201:1000
group <- c(1, 1, 1, 2, 2, 2)
tcc <- new("TCC", hypoData, group)
tcc <- calcNormFactors(tcc, norm.method = "tmm", iteration = 0)
normalized.count <- getNormalizedData(tcc)
apply(normalized.count[nonDEG, ], 2, median)


###################################################
### code chunk number 39: TCC.Rnw:1023-1032
###################################################
library(TCC)
data(hypoData)  
group <- c(1, 1, 1, 2, 2, 2)
nonDEG <- 201:1000
tcc <- new("TCC", hypoData, group)
tcc <- calcNormFactors(tcc, norm.method = "deseq", test.method = "deseq",
                       iteration = 1, FDR = 0.1, floorPDEG = 0.05)
normalized.count <- getNormalizedData(tcc)
apply(normalized.count[nonDEG, ], 2, median)


###################################################
### code chunk number 40: TCC.Rnw:1037-1067
###################################################
library(TCC)
data(hypoData)  
nonDEG <- 201:1000
group <- c(1, 1, 1, 2, 2, 2)
FDR <- 0.1
floorPDEG <- 0.05
cds <- newCountDataSet(hypoData, group)
###  Step 1  ###
cds <- estimateSizeFactors(cds)
###  Step 2  ###
cds <- estimateDispersions(cds)
result <- nbinomTest(cds, 1, 2)
result$pval[is.na(result$pval)] <- 1
result$padj[is.na(result$padj)] <- 1
q.value <- result$padj
if (sum(q.value < FDR) > (floorPDEG * nrow(hypoData))) {
  is.DEG <- as.logical(q.value < FDR)
} else {
  is.DEG <- as.logical(rank(result$pval, ties.method = "min") <=
                       nrow(hypoData) * floorPDEG)
}
###  Step 3  ###
cds <- newCountDataSet(hypoData[!is.DEG, ], group)
cds <- estimateSizeFactors(cds)
norm.factors <- sizeFactors(cds) / colSums(hypoData)
norm.factors <- norm.factors / mean(norm.factors)
effective.libsizes <- colSums(hypoData) * norm.factors
normalized.count <- sweep(hypoData, 2,
                          mean(effective.libsizes) / effective.libsizes, "*")
apply(normalized.count[nonDEG, ], 2, median)


###################################################
### code chunk number 41: TCC.Rnw:1077-1086
###################################################
library(TCC)
data(hypoData)  
nonDEG <- 201:1000
group <- c(1, 2)
tcc <- new("TCC", hypoData[, c(1, 4)], group)
tcc <- calcNormFactors(tcc, norm.method = "deseq", test.method = "deseq",
                       iteration = 1, FDR = 0.1, floorPDEG = 0.05)
normalized.count <- getNormalizedData(tcc)
apply(normalized.count[nonDEG, ], 2, median)


###################################################
### code chunk number 42: TCC.Rnw:1091-1121
###################################################
library(TCC)
data(hypoData) 
nonDEG <- 201:1000
group <- c(1, 2)
FDR <- 0.1
floorPDEG <- 0.05
cds <- newCountDataSet(hypoData[,c(1, 4)], group)
###  Step 1  ###
cds <- estimateSizeFactors(cds)
###  Step 2  ###
cds <- estimateDispersions(cds, method = "blind", sharingMode = "fit-only")
result <- nbinomTest(cds, 1, 2)
result$pval[is.na(result$pval)] <- 1
result$padj[is.na(result$padj)] <- 1
q.value <- result$padj
if (sum(q.value < FDR) > (floorPDEG * nrow(hypoData))) {
  is.DEG <- as.logical(q.value < FDR)
} else {
  is.DEG <- as.logical(rank(result$pval, ties.method = "min") <=
                       nrow(hypoData) * floorPDEG)
}
###  Step 3  ###
cds <- newCountDataSet(hypoData[!is.DEG, c(1, 4)], group)
cds <- estimateSizeFactors(cds)
norm.factors <- sizeFactors(cds) / colSums(hypoData[, c(1, 4)])
norm.factors <- norm.factors / mean(norm.factors)
effective.libsizes <- colSums(hypoData[, c(1, 4)]) * norm.factors
normalized.count <- sweep(hypoData[, c(1, 4)], 2,
                          mean(effective.libsizes) / effective.libsizes, "*")
apply(normalized.count[nonDEG, ], 2, median)


###################################################
### code chunk number 43: TCC.Rnw:1130-1138
###################################################
library(TCC)
data(hypoData)
nonDEG <- 201:1000
group <- c(1, 2)
cds <- newCountDataSet(hypoData[, c(1, 4)], group)
cds <- estimateSizeFactors(cds)
normalized.count <- counts(cds, normalized = TRUE)
apply(normalized.count[nonDEG, ], 2, median)


###################################################
### code chunk number 44: TCC.Rnw:1152-1156
###################################################
library(TCC)
data(hypoData_mg)
nonDEG <- 201:1000
summary(hypoData_mg[nonDEG, ])


###################################################
### code chunk number 45: TCC.Rnw:1161-1162
###################################################
apply(hypoData_mg[nonDEG, ], 2, median)


###################################################
### code chunk number 46: TCC.Rnw:1164-1165
###################################################
hypoData_mg.median <- apply(hypoData_mg[nonDEG, ], 2, median)


###################################################
### code chunk number 47: TCC.Rnw:1170-1182
###################################################
library(TCC)
data(hypoData_mg)
nonDEG <- 201:1000
group <- c(1, 1, 1, 2, 2, 2, 3, 3, 3)
tcc <- new("TCC", hypoData_mg, group)
design <- model.matrix(~ as.factor(group))
coef <- 2:length(unique(group))
tcc <- calcNormFactors(tcc, norm.method = "tmm", test.method = "edger",
                        iteration = 3, design = design, coef = coef)
normalized.count <- getNormalizedData(tcc)
apply(normalized.count[nonDEG, ], 2, median)
range(apply(normalized.count[nonDEG, ], 2, median))


###################################################
### code chunk number 48: TCC.Rnw:1184-1185
###################################################
normByiDEGES <- range(apply(normalized.count[nonDEG, ], 2, median))


###################################################
### code chunk number 49: TCC.Rnw:1192-1201
###################################################
library(TCC)
data(hypoData_mg)
nonDEG <- 201:1000
group <- c(1, 1, 1, 2, 2, 2, 3, 3, 3)
tcc <- new("TCC", hypoData_mg, group)
tcc <- calcNormFactors(tcc, norm.method = "tmm", iteration = 0)
normalized.count <- getNormalizedData(tcc)
apply(normalized.count[nonDEG, ], 2, median)
range(apply(normalized.count[nonDEG, ], 2, median))


###################################################
### code chunk number 50: TCC.Rnw:1203-1204
###################################################
normByTMM <- range(apply(normalized.count[nonDEG, ], 2, median))


###################################################
### code chunk number 51: TCC.Rnw:1253-1260
###################################################
library(TCC)
data(hypoData)
group <- c(1, 1, 1, 2, 2, 2)
tcc <- new("TCC", hypoData, group)
tcc <- calcNormFactors(tcc, norm.method = "tmm", test.method = "edger", 
                       iteration = 3, FDR = 0.1, floorPDEG = 0.05)
tcc <- estimateDE(tcc, test.method = "edger", FDR = 0.1)


###################################################
### code chunk number 52: TCC.Rnw:1267-1269
###################################################
result <- getResult(tcc, sort = TRUE)
head(result)


###################################################
### code chunk number 53: TCC.Rnw:1274-1275
###################################################
table(tcc$estimatedDEG) 


###################################################
### code chunk number 54: TCC.Rnw:1287-1288
###################################################
plot(tcc)


###################################################
### code chunk number 55: TCC.Rnw:1303-1316
###################################################
set.seed(1000)
library(TCC)
data(hypoData)
samplesize <- 100
group <- c(1, 1, 1, 2, 2, 2)
tcc <- new("TCC", hypoData, group)
tcc <- calcNormFactors(tcc, norm.method = "tmm", test.method = "edger", 
                       iteration = 3, FDR = 0.1, floorPDEG = 0.05)
tcc <- estimateDE(tcc, test.method = "bayseq", 
                  FDR = 0.1, samplesize = samplesize)
result <- getResult(tcc, sort = TRUE)
head(result)
table(tcc$estimatedDEG)


###################################################
### code chunk number 56: TCC.Rnw:1331-1352
###################################################
set.seed(1000)
library(TCC)
data(hypoData)
samplesize <- 100
group <- c(1, 1, 1, 2, 2, 2)
tcc <- new("TCC", hypoData, group)
tcc <- calcNormFactors(tcc, norm.method = "tmm", test.method = "edger", 
                       iteration = 3, FDR = 0.1, floorPDEG = 0.05)
effective.libsizes <- colSums(tcc$count) * tcc$norm.factors
groups <- list(NDE = rep(1, length(group)), DE = group)
cD <- new("countData", data = tcc$count, replicates = group,
          libsizes = effective.libsizes, groups = groups)
cD <- getPriors.NB(cD, samplesize = samplesize, 
                   estimation = "QL", cl = NULL)
cD <- getLikelihoods.NB(cD, pET = "BIC", cl = NULL)
tmp <- topCounts(cD, group = "DE", number = nrow(tcc$count))
p.value <- 1 - tmp$Likelihood
q.value <- tmp$FDR
result <- cbind(p.value, q.value)
rownames(result) <- rownames(tmp)
head(result)


###################################################
### code chunk number 57: TCC.Rnw:1372-1386
###################################################
library(TCC)
data(hypoData)
group <- c(1, 2)
tcc <- new("TCC", hypoData[, c(1, 4)], group)
head(tcc$count)
tcc$group
tcc <- calcNormFactors(tcc, norm.method = "deseq", test.method = "deseq",
                       iteration = 3, FDR = 0.1, floorPDEG = 0.05)
tcc$norm.factors
tcc <- estimateDE(tcc, test.method = "deseq", 
                  FDR = 0.1)
result <- getResult(tcc, sort = TRUE)
head(result)
table(tcc$estimatedDEG)


###################################################
### code chunk number 58: TCC.Rnw:1409-1426
###################################################
library(TCC)
data(hypoData_mg)
group <- c(1, 1, 1, 2, 2, 2, 3, 3, 3)
tcc <- new("TCC", hypoData_mg, group)
###  Normalization  ###
design <- model.matrix(~ as.factor(group))
coef <- 2:length(unique(group))
tcc <- calcNormFactors(tcc, norm.method = "tmm", test.method = "edger",
                        iteration = 1, design = design, coef = coef)
###  DE analysis  ###
set.seed(1000)
samplesize <- 100
tcc <- estimateDE(tcc, test.method = "bayseq", 
                  FDR = 0.1, samplesize = samplesize)
result <- getResult(tcc, sort = TRUE)
head(result)
table(tcc$estimatedDEG)


###################################################
### code chunk number 59: TCC.Rnw:1434-1435
###################################################
sum(result$q.value < 0.2)


###################################################
### code chunk number 60: TCC.Rnw:1445-1462
###################################################
set.seed(1000)
samplesize <- 100
effective.libsizes <- colSums(tcc$count) * tcc$norm.factors
groups <- list(NDE = rep(1, length(group)), DE = group)
cD <- new("countData", data = tcc$count, replicates = group,
          libsizes = effective.libsizes, groups = groups)
cD <- getPriors.NB(cD, samplesize = samplesize, 
                   estimation = "QL", cl = NULL)
cD <- getLikelihoods.NB(cD, pET = "BIC", cl = NULL)
tmp <- topCounts(cD, group = "DE", number = nrow(tcc$count))
p.value <- 1 - tmp$Likelihood
q.value <- tmp$FDR
result <- cbind(p.value, q.value)
rownames(result) <- rownames(tmp)
head(result)
sum(q.value < 0.1)
sum(q.value < 0.2)


###################################################
### code chunk number 61: TCC.Rnw:1473-1488
###################################################
library(TCC)
data(hypoData_mg)
group <- c(1, 1, 1, 2, 2, 2, 3, 3, 3)
tcc <- new("TCC", hypoData_mg, group)
###  Normalization  ###
design <- model.matrix(~ as.factor(group))
coef <- 2:length(unique(group))
tcc <- calcNormFactors(tcc, norm.method = "tmm", test.method = "edger",
                        iteration = 1, design = design, coef = coef)
###  DE analysis  ###
tcc <- estimateDE(tcc, test.method = "edger", 
                  FDR = 0.1, design = design, coef = coef)
result <- getResult(tcc, sort = TRUE)
head(result)
table(tcc$estimatedDEG)


###################################################
### code chunk number 62: TCC.Rnw:1495-1520
###################################################
library(TCC)
data(hypoData_mg)
group <- c(1, 1, 1, 2, 2, 2, 3, 3, 3)
tcc <- new("TCC", hypoData_mg, group)
###  Normalization  ###
design <- model.matrix(~ as.factor(group))
coef <- 2:length(unique(group))
tcc <- calcNormFactors(tcc, norm.method = "tmm", test.method = "edger",
                        iteration = 1, design = design, coef = coef)
###  DE analysis  ###
d <- DGEList(tcc$count, group = group)
d$samples$norm.factors <- tcc$norm.factors
d <- estimateGLMCommonDisp(d, design)
d <- estimateGLMTrendedDisp(d, design)
d <- estimateGLMTagwiseDisp(d, design)
fit <- glmFit(d, design)
lrt <- glmLRT(fit, coef = coef)
tmp <- topTags(lrt, n = nrow(tcc$count))
p.value <- tmp$table$PValue
q.value <- tmp$table$FDR
result <- cbind(p.value, q.value)
rownames(result) <- rownames(tmp)
head(result)
sum(q.value < 0.1)
sum(q.value < 0.2)


###################################################
### code chunk number 63: TCC.Rnw:1534-1550
###################################################
library(TCC)
data(hypoData_mg)
group <- c(1, 1, 1, 2, 2, 2, 3, 3, 3)
tcc <- new("TCC", hypoData_mg, group)
###  Normalization  ###
design <- model.matrix(~ as.factor(group))
coef <- 2:length(unique(group))
tcc <- calcNormFactors(tcc, norm.method = "tmm", test.method = "edger",
                        iteration = 1, design = design, coef = coef)
###  DE analysis  ###
coef <- 3
tcc <- estimateDE(tcc, test.method = "edger", 
                  FDR = 0.1, design = design, coef = coef)
result <- getResult(tcc, sort = TRUE)
head(result)
table(tcc$estimatedDEG)


###################################################
### code chunk number 64: TCC.Rnw:1561-1578
###################################################
library(TCC)
data(hypoData_mg)
group <- c(1, 1, 1, 2, 2, 2, 3, 3, 3)
tcc <- new("TCC", hypoData_mg, group)
###  Normalization  ###
design <- model.matrix(~ as.factor(group))
coef <- 2:length(unique(group))
tcc <- calcNormFactors(tcc, norm.method = "tmm", test.method = "edger",
                        iteration = 1, design = design, coef = coef)
###  DE analysis  ###
fit1 <- count ~ condition
fit0 <- count ~ 1
tcc <- estimateDE(tcc, test.method = "deseq", 
                  FDR = 0.1, fit0 = fit0, fit1 = fit1)
result <- getResult(tcc, sort = TRUE)
head(result)
table(tcc$estimatedDEG)


###################################################
### code chunk number 65: TCC.Rnw:1588-1614
###################################################
library(TCC)
data(hypoData_mg)
group <- c(1, 1, 1, 2, 2, 2, 3, 3, 3)
tcc <- new("TCC", hypoData_mg, group)
###  Normalization  ###
design <- model.matrix(~ as.factor(group))
coef <- 2:length(unique(group))
tcc <- calcNormFactors(tcc, norm.method = "tmm", test.method = "edger",
                        iteration = 1, design = design, coef = coef)
###  DE analysis  ###
fit1 <- count ~ condition
fit0 <- count ~ 1
cds <- newCountDataSet(tcc$count, group)
sizeFactors(cds) <- tcc$norm.factors * colSums(tcc$count)
cds <- estimateDispersions(cds)
reduced.model <- fitNbinomGLMs(cds, fit0)
full.model <- fitNbinomGLMs(cds, fit1)
p.value <- nbinomGLMTest(full.model, reduced.model)
p.value[is.na(p.value)] <- 1
q.value <- p.adjust(p.value, method = "BH")
tmp <- cbind(p.value, q.value)
rownames(tmp) <- tcc$gene_id
result <- tmp[order(p.value), ]
head(result)
sum(q.value < 0.1)
sum(q.value < 0.2)


###################################################
### code chunk number 66: TCC.Rnw:1645-1654
###################################################
set.seed(1000)
library(TCC)
tcc <- simulateReadCounts(Ngene = 1000, PDEG = 0.2, 
                              DEG.assign = c(0.9, 0.1),
                              DEG.foldchange = c(4, 4), 
                              replicates = c(3, 3))
dim(tcc$count)
head(tcc$count)
tcc$group


###################################################
### code chunk number 67: TCC.Rnw:1677-1678
###################################################
str(tcc$simulation)


###################################################
### code chunk number 68: TCC.Rnw:1687-1688
###################################################
table(tcc$simulation$trueDEG)


###################################################
### code chunk number 69: TCC.Rnw:1701-1706
###################################################
tcc <- calcNormFactors(tcc, norm.method = "tmm", test.method = "edger", 
                       iteration = 1, FDR = 0.1, floorPDEG = 0.05)
tcc <- estimateDE(tcc, test.method = "edger", FDR = 0.1)
result <- getResult(tcc, sort = TRUE)
head(result)


###################################################
### code chunk number 70: TCC.Rnw:1717-1718
###################################################
calcAUCValue(tcc)


###################################################
### code chunk number 71: TCC.Rnw:1720-1721
###################################################
auc.degesedger <- calcAUCValue(tcc)


###################################################
### code chunk number 72: TCC.Rnw:1726-1728
###################################################
AUC(rocdemo.sca(truth = as.numeric(tcc$simulation$trueDEG != 0),
                data = -tcc$stat$rank))


###################################################
### code chunk number 73: TCC.Rnw:1737-1740
###################################################
tcc <- calcNormFactors(tcc, norm.method = "tmm", iteration = 0)
tcc <- estimateDE(tcc, test.method = "edger", FDR = 0.1)
calcAUCValue(tcc)


###################################################
### code chunk number 74: TCC.Rnw:1745-1754
###################################################
d <- DGEList(counts = tcc$count, group = tcc$group$group)
d <- calcNormFactors(d)
d$samples$norm.factors <- d$samples$norm.factors / mean(d$samples$norm.factors)
d <- estimateCommonDisp(d)
d <- estimateTagwiseDisp(d)
result <- exactTest(d)
result$table$PValue[is.na(result$table$PValue)] <- 1
AUC(rocdemo.sca(truth = as.numeric(tcc$simulation$trueDEG != 0),
                data = -rank(result$table$PValue)))


###################################################
### code chunk number 75: TCC.Rnw:1756-1762
###################################################
set.seed(1000)
samplesize <- 100
tcc <- calcNormFactors(tcc, norm.method = "tmm", test.method = "bayseq",
                       iteration = 1, samplesize = samplesize)
tcc <- estimateDE(tcc, test.method = "edger", FDR = 0.1)
auc.degestbt <- calcAUCValue(tcc)


###################################################
### code chunk number 76: TCC.Rnw:1771-1777
###################################################
set.seed(1000)
samplesize <- 100
tcc <- calcNormFactors(tcc, norm.method = "tmm", test.method = "bayseq",
                       iteration = 1, samplesize = samplesize)
tcc <- estimateDE(tcc, test.method = "edger", FDR = 0.1)
calcAUCValue(tcc)


###################################################
### code chunk number 77: TCC.Rnw:1800-1809
###################################################
set.seed(1000)
library(TCC)
tcc <- simulateReadCounts(Ngene = 1000, PDEG = 0.2, 
                              DEG.assign = c(0.9, 0.1),
                              DEG.foldchange = c(4, 4), 
                              replicates = c(1, 1))
dim(tcc$count)
head(tcc$count)
tcc$group


###################################################
### code chunk number 78: TCC.Rnw:1818-1822
###################################################
tcc <- calcNormFactors(tcc, norm.method = "deseq", test.method = "deseq",
                       iteration = 1, FDR = 0.1, floorPDEG = 0.05)
tcc <- estimateDE(tcc, test.method = "deseq")
calcAUCValue(tcc)


###################################################
### code chunk number 79: TCC.Rnw:1829-1832
###################################################
tcc <- calcNormFactors(tcc, norm.method = "deseq", iteration = 0)
tcc <- estimateDE(tcc, test.method = "deseq")
calcAUCValue(tcc)


###################################################
### code chunk number 80: TCC.Rnw:1840-1850
###################################################
cds <- newCountDataSet(tcc$count, tcc$group$group)
cds <- estimateSizeFactors(cds)
norm.factors <- sizeFactors(cds) / colSums(tcc$count)
norm.factors <- norm.factors / mean(norm.factors)
sizeFactors(cds) <- colSums(tcc$count) * norm.factors
cds <- estimateDispersions(cds, method="blind", sharingMode="fit-only")
result <- nbinomTest(cds, 1, 2)
result$pval[is.na(result$pval)] <- 1
AUC(rocdemo.sca(truth = as.numeric(tcc$simulation$trueDEG != 0),
                data = -rank(result$pval))) 


###################################################
### code chunk number 81: TCC.Rnw:1859-1866
###################################################
cds <- newCountDataSet(tcc$count, tcc$group$group)
cds <- estimateSizeFactors(cds)
cds <- estimateDispersions(cds, method="blind", sharingMode="fit-only")
result <- nbinomTest(cds, 1, 2)
result$pval[is.na(result$pval)] <- 1
AUC(rocdemo.sca(truth = as.numeric(tcc$simulation$trueDEG != 0),
                data = -rank(result$pval))) 


###################################################
### code chunk number 82: TCC.Rnw:1887-1896
###################################################
set.seed(1000)
library(TCC)
tcc <- simulateReadCounts(Ngene = 1000, PDEG = 0.3,
                         DEG.assign = c(0.7, 0.2, 0.1),
                         DEG.foldchange = c(3, 10, 6),
                         replicates = c(2, 4, 3))
dim(tcc$count)
tcc$group
head(tcc$count)


###################################################
### code chunk number 83: TCC.Rnw:1905-1906
###################################################
plotFCPseudocolor(tcc)


###################################################
### code chunk number 84: TCC.Rnw:1924-1934
###################################################
set.seed(1000)
library(TCC)
tcc <- simulateReadCounts(Ngene = 10000, PDEG = 0.34,
               DEG.assign = c(0.1, 0.3, 0.05, 0.1, 0.05, 0.21, 0.09, 0.1),
               DEG.foldchange = c(3.1, 13, 2, 1.5, 9, 5.6, 4, 2),
               replicates = c(1, 1, 2, 1, 1, 1, 1, 1))
dim(tcc$count)
tcc$group
head(tcc$count)
plotFCPseudocolor(tcc)


###################################################
### code chunk number 85: TCC.Rnw:1958-1965
###################################################
set.seed(1000)
library(TCC)
tcc <- simulateReadCounts(Ngene = 20000, PDEG = 0.30, 
                              DEG.assign = c(0.85, 0.15),
                              DEG.foldchange = c(8, 16), 
                              replicates = c(2, 2))
head(tcc$count)


###################################################
### code chunk number 86: TCC.Rnw:1972-1973
###################################################
plot(tcc)


###################################################
### code chunk number 87: TCC.Rnw:1980-1984
###################################################
normalized.count <- getNormalizedData(tcc)
colSums(normalized.count)
colSums(tcc$count)
mean(colSums(tcc$count))


###################################################
### code chunk number 88: TCC.Rnw:1987-1992
###################################################
xy <- plot(tcc)
isnot.na <- as.logical(xy[, 1] != min(xy[, 1]))
median.G1 <- median(xy[(tcc$simulation$trueDEG == 1) & isnot.na, 2])
median.G2 <- median(xy[(tcc$simulation$trueDEG == 2) & isnot.na, 2])
median.nonDEG <- median(xy[(tcc$simulation$trueDEG == 0) & isnot.na, 2])


###################################################
### code chunk number 89: TCC.Rnw:2004-2005
###################################################
plot(tcc, median.lines = TRUE) 


###################################################
### code chunk number 90: TCC.Rnw:2008-2012
###################################################
tcc <- calcNormFactors(tcc, "tmm", "edger", iteration = 3, FDR = 0.1, floorPDEG = 0.05)
xy <- plot(tcc)
isnot.na <- as.logical(xy[, 1] != min(xy[, 1]))
median.nonDEG <- median(xy[(tcc$simulation$trueDEG == 0) & isnot.na, 2])


###################################################
### code chunk number 91: TCC.Rnw:2020-2023
###################################################
tcc <- calcNormFactors(tcc, norm.method = "tmm", test.method = "edger", 
                       iteration = 3, FDR = 0.1, floorPDEG = 0.05)
plot(tcc, median.line = TRUE)


###################################################
### code chunk number 92: TCC.Rnw:2033-2034
###################################################
sessionInfo()


